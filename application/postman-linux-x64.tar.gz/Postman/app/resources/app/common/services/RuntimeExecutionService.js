// ###### WARNING: DO NOT REQUIRE NON-ISOMORPHIC LIBRARIES HERE
let _ = require('lodash'),
  async = require('async'),

  // ###### WARNING: DO NOT REQUIRE NON-ISOMORPHIC LIBRARIES HERE

  // Character detection to node encoding map
  CHARDET_BUFF_MAP = {
    ASCII: 'ascii',
    'UTF-8': 'utf8',
    'UTF-16LE': 'utf16le',
    'ISO-8859-1': 'latin1'
  },

  // maximum allowed response size if truncate large response option is set for
  // the run
  MAX_RESPONSE_SIZE = 300 * 1024,

  detectEncoding = (buff) => CHARDET_BUFF_MAP[chardet.detect(buff)],

  isBrowser = false,


  // TODO: Implement these using a dependency injection model like awilix
  fs,
  os,
  app,
  path,
  dialog,
  chardet,
  PostmanFs,
  CookieJar,
  AuthLoader,
  dryRunRequest,
  CookieManager,
  getSystemProxy,
  SerializedError,
  collectionRunner,
  sanitizeFilename,
  postmanCollectionSdk,

  defaultWorkingDir,

  activeRuns = {};

/**
 * Helper function to get the file extension given a mime-type
 * @param {String} mimeType
 */
function __getProbableExtension (mimeType) {
  var mimeExtensions = [
    {
      typeSubstring: 'text',
      extension: '.txt'
    },
    {
      typeSubstring: 'json',
      extension: '.json'
    },
    {
      typeSubstring: 'javascript',
      extension: '.js'
    },
    {
      typeSubstring: 'pdf',
      extension: '.pdf'
    },
    {
      typeSubstring: 'png',
      extension: '.png'
    },
    {
      typeSubstring: 'jpg',
      extension: '.jpg'
    },
    {
      typeSubstring: 'jpeg',
      extension: '.jpg'
    },
    {
      typeSubstring: 'gif',
      extension: '.gif'
    },
    {
      typeSubstring: 'excel',
      extension: '.xls'
    },
    {
      typeSubstring: 'zip',
      extension: '.zip'
    },
    {
      typeSubstring: 'compressed',
      extension: '.zip'
    },
    {
      typeSubstring: 'audio/wav',
      extension: '.wav'
    },
    {
      typeSubstring: 'tiff',
      extension: '.tiff'
    },
    {
      typeSubstring: 'shockwave',
      extension: '.swf'
    },
    {
      typeSubstring: 'powerpoint',
      extension: '.ppt'
    },
    {
      typeSubstring: 'mpeg',
      extension: '.mpg'
    },
    {
      typeSubstring: 'quicktime',
      extension: '.mov'
    },
    {
      typeSubstring: 'html',
      extension: '.html'
    },
    {
      typeSubstring: 'css',
      extension: '.css'
    }
  ];

  for (var i = 0; i < mimeExtensions.length; i++) {
    if (mimeType.indexOf(mimeExtensions[i].typeSubstring) > -1) {
      return mimeExtensions[i].extension;
    }
  }

  return '';
}


// #region API Functions

/**
 * @private
 */
function trackRun (executionId, run) {
  activeRuns[executionId] = run;
}

/**
 * @private
 */
function addAborter (executionId, aborter) {
  activeRuns[executionId] && (activeRuns[executionId].aborter = aborter);
}

/**
 * @private
 */
function removeAborter (executionId) {
  activeRuns[executionId] && (delete activeRuns[executionId].aborter);
}

/**
 * @private
 * Sanitizes options to be sent to runtime. Mostly converting objects into SDK instances.
 *
 * @param {Object} rawOptions
 */
function sanitizeRunOptions (rawOptions) {
  if (!rawOptions) {
    return;
  }

  if (rawOptions.useSystemProxy && !!getSystemProxy) {
    rawOptions.systemProxy = getSystemProxy;
  }

  if (rawOptions.proxies) {
    rawOptions.proxies = new postmanCollectionSdk.ProxyConfigList({}, rawOptions.proxies);
  }

  rawOptions.certificates = new postmanCollectionSdk.CertificateList({}, rawOptions.certificates);
}

/**
 * @private
 * Save the given stream to a file the user chooses
 *
 * @param {Object} contentInfo
 * @param {Buffer} stream
 */
function saveStreamToFile (contentInfo, stream, cb) {
  let name;

  // sdkResponse override
  if (contentInfo && contentInfo.fileName) {
    name = contentInfo.fileName || '';
  }

  if (_.isEmpty(name)) {
    name = 'response';
    name = (contentInfo && contentInfo.mimeType) ? `${name}${__getProbableExtension(contentInfo.mimeType)}` : name;
  }

  // TODO: Implement browser specific logic here
  if (isBrowser) {
    return;
  }

  // WARNING: All usages below require native dependencies hence be careful in browser environment

  name = sanitizeFilename(name, { replacement: '-' });

  dialog.showSaveDialog({
    title: 'Select path to save file',
    defaultPath: path.join(os.homedir(), name)
  }).then((result) => {
    if (result.canceled) {
      // If the request was cancelled then don't do anything, not even call the callback;
      return;
    }

    fs.writeFile(result.filePath, stream, (err) => {
      return cb(err);
    });
  })
  .catch(cb);
}

/**
 * Abort and cleanup an existing collection run
 *
 * @param {String} executionId - The execution id to terminate or dispose
 * @param {Function} emit - emitter to call to denote the execution has terminated/disposed
 */
function disposeRun (executionId, emit = _.noop) {
  if (!executionId || !activeRuns[executionId]) {
    return;
  }

  const run = activeRuns[executionId];

  run.host && run.host.dispose && run.host.dispose();

  // dispose the reference
  activeRuns[executionId] = null;

  emit({
    name: 'terminated',
    namespace: 'requestexecution',
    data: { id: executionId }
  });
}

/**
 * @public
 * Stops and disposes an existing collection run
 *
 * @param {String} executionId - The execution id to terminate or dispose
 * @param {Function} emit - emitter to call to denote the execution has terminated/disposed
 */
function stopRun (executionId, emit) {
  if (!executionId || !activeRuns[executionId]) {
    return;
  }

  const run = activeRuns[executionId];

  run.aborter && run.aborter.abort();
  run.abort();

  disposeRun(executionId, emit);
}

/**
 * @public
 * Pause the current collection run
 *
 * @param {String} executionId
 */
function pauseRun (executionId) {
  if (!executionId || !activeRuns[executionId]) {
    return;
  }

  activeRuns[executionId].pause();
}

/**
 * @public
 * Resume the paused current collection run
 *
 * @param {String} executionId
 */
function resumeRun (executionId) {
  if (!executionId || !activeRuns[executionId]) {
    return;
  }

  activeRuns[executionId].resume();
}

/**
 * @public
 * Start a collection run with the given collection and variables
 *
 * @param {Object} info
 * @param {Object} collection
 * @param {Object} variables
 * @param {Object} options
 */
function startRun (info, collection, variables, options = {}, emit) {
  var sdkCollection = new postmanCollectionSdk.Collection(collection),
    cookiePartitionId = options && options.cookiePartitionId,
    cookieJar;

  // We have the CookieJar
  if (CookieJar) {
    cookieJar = new CookieJar(cookiePartitionId, {
      programmaticAccess: options.cookieConfiguration,
      readFromDB: !_.get(info, 'runWithEmptyCookieJar', false),
      writeToDB: !_.get(info, 'disableRealtimeCookieJarWrite', false),
      onCookieAccessDenied: (domain) => {
        let message = `Unable to access "${domain}" cookie store.` +
          ' Try whitelisting the domain in "Manage Cookies" screen.' +
          ' View more detailed instructions in the Learning Center: https://go.pstmn.io/docs-cookies';

        emit({
          name: 'log',
          namespace: 'console',
          data: {
            id: info.id,
            cursor: {},
            level: 'warn',
            messages: [message]
          }
        });
      }
    });

    _.set(options, ['requester', 'cookieJar'], cookieJar);
  }

  // fileResolver defined and we have PostmanFs
  if (options.fileResolver && !!PostmanFs) {
    let { workingDir, insecureFileRead, fileWhitelist } = options.fileResolver;

    _.set(options, 'fileResolver', new PostmanFs(workingDir || defaultWorkingDir, insecureFileRead, fileWhitelist));
  }

  // sanitize
  sanitizeRunOptions(options);

  // add variables
  variables.environment && (options.environment = new postmanCollectionSdk.VariableScope(variables.environment));
  variables.globals && (options.globals = new postmanCollectionSdk.VariableScope(variables.globals));

  collectionRunner.run(sdkCollection, options, function (err, run) {
    if (err) {
      pm.logger.error('RuntimeExecutionService~startRun - Error in starting the run', err);
      return;
    }

    trackRun(info.id, run);

    run.start({
      start (err) {
        emit({
          name: 'started',
          namespace: 'requestexecution',
          data: info
        });

        err && emit({
          name: 'startError',
          namespace: 'requestexecution',
          data: err
        });
      },

      console (cursor, level, ...param) {
        emit({
          name: 'log',
          namespace: 'console',
          data: {
            id: info.id,
            cursor: cursor,
            level: level,
            messages: param
          }
        });
      },

      beforeItem (err, cursor, item) {
        const itemObj = {
          id: item.id,
          name: item.name,
          request: {
            url: _.invoke(item, 'request.url.toString', ''),
            method: _.get(item, 'request.method', '')
          }
        };

        emit({
          name: 'beforeItem',
          namespace: 'requestexecution',
          data: {
            id: info.id,
            cursor,
            error: err,
            item: itemObj
          }
        });
      },

      beforeRequest (err, cursor, request, item, aborter) {
        addAborter(info.id, aborter);
      },

      exception (cursor, exception) {
        emit({
          name: 'exception',
          namespace: 'requestexecution',
          data: {
            id: info.id,
            error: new SerializedError(exception)
          }
        });

        emit({
          name: 'exception',
          namespace: 'console',
          data: {
            id: info.id,
            cursor: cursor,
            error: exception
          }
        });
      },

      assertion (cursor, assertions) {
        emit({
          name: 'assertionsReceived',
          namespace: 'requestexecution',
          data: {
            id: info.id,
            cursor,
            assertions: assertions
          }
        });
      },

      script (err, cursor, result, script, event) {
        if (err) {
          emit({
            name: 'error',
            namespace: 'requestexecution',
            data: {
              id: info.id,
              cursor,
              error: new SerializedError(err),
              phase: (event && event.listen) || 'script'
            }
          });

          return;
        }

        // @note this option is only set in Runner as `false` because
        // Runner can choose to update or not based on user selection.
        // but we always update variable session for Requester.
        const updateSessionVariables = _.get(info, 'updateSessionVariables', true);

        result.globals && emit({
          name: 'globalsUpdated',
          namespace: 'variableupdates',
          data: {
            id: info.id,
            updateSessionVariables,
            globals: result.globals
          }
        });

        result.environment && emit({
          name: 'environmentUpdated',
          namespace: 'variableupdates',
          data: {
            id: info.id,
            updateSessionVariables,
            environment: result.environment
          }
        });

        if (result.collectionVariables) {
          // update collectionVariables VariableScope's id to collection session id because
          // collection variables are stored as VariableList and sessions are not first class
          // citizen in runtime.
          info.collectionVariablesSessionId &&
            (result.collectionVariables.id = info.collectionVariablesSessionId);

          emit({
            name: 'collectionVariablesUpdated',
            namespace: 'variableupdates',
            data: {
              id: info.id,
              updateSessionVariables,
              collectionVariables: result.collectionVariables
            }
          });
        }
      },

      request (err, cursor, response, request, item, cookies, history) {
        let consolePayload = {},
          requestJSON = request.toJSON();

        let executionData = _.get(history, 'execution.data');

        consolePayload.id = info.id;
        consolePayload.cursor = cursor;
        consolePayload.history = history;

        consolePayload.request = {
          url: request && request.url && request.url.toString(),
          method: requestJSON.method,
          headers: request && request.headers && request.headers.toJSON(),
          httpVersion: _.get(_.first(executionData), 'request.httpVersion', ''),
          body: requestJSON.body,
          certificate: requestJSON.certificate,
          proxy: requestJSON.proxy
        };

        if (response) {
          consolePayload.response = {
            responseTime: response.responseTime,
            code: response.code,
            headers: response.headers && response.headers.toJSON(),
            status: response.reason(),
            httpVersion: _.get(_.last(executionData), 'response.httpVersion', ''),
            body: response.text(),
            contentInfo: _.isFunction(response.contentInfo) && response.contentInfo()
          };
        }

        if (err) {
          consolePayload.error = err.message;
        }

        emit({
          name: 'net',
          namespace: 'console',
          data: consolePayload
        });
      },

      responseStart (err, cursor, response, request, item, cookies, history) {
        // send the actual request that was sent over network
        // always send request even if there is an error
        request && emit({
          name: 'requestDispatched',
          namespace: 'requestexecution',
          data: {
            id: info.id,
            request: request.toJSON(),
            requestSize: request.size()
          }
        });

        if (err) {
          let error = new SerializedError(err);

          error.sessions = _.get(history, 'execution.sessions');

          emit({
            name: 'error',
            namespace: 'requestexecution',
            data: {
              id: info.id,
              cursor,
              error,
              phase: 'request'
            }
          });

          return;
        }

        if (!response) {
          return;
        }

        // There is a possibility that there are redirects in that case we will have multiple
        // timings, the last timing is the one that we need.
        // NOTE: The timing information will be partial here, we can only get the full
        // after the completion of the request
        let executionData = _.last(_.get(history, 'execution.data')),
          timings = executionData && executionData.timings,
          sessionId = _.get(executionData, 'session.id'),
          networkData = _.get(history, ['execution', 'sessions', sessionId]),
          network = networkData && {
            localAddress: _.get(networkData.addresses, 'local.address'),
            remoteAddress: _.get(networkData.addresses, 'remote.address'),
            authorized: _.get(networkData.tls, 'authorized'),
            authorizationError: _.get(networkData.tls, 'authorizationError'),
            tlsProtocol: _.get(networkData.tls, 'protocol'),
            cipherName: _.get(networkData.tls, 'cipher.name'),
            certificateCN: _.get(networkData.tls, 'peerCertificate.subject.commonName'),
            issuerCN: _.get(networkData.tls, 'peerCertificate.issuer.commonName'),
            validUntil: _.get(networkData.tls, 'peerCertificate.validTo')
          };

        // send response meta data (We do not have the timing information here)
        // FUTURE: Add time some timing information here to start of
        emit({
          name: 'responseMetaReceived',
          namespace: 'requestexecution',
          data: {
            id: info.id,
            meta: {
              code: response.code,
              status: response.status,
              responseSize: response.size(),
              network,
              timingPhases: postmanCollectionSdk.Response.timingPhases(timings)
            }
          }
        });

        // Send headers from the response head
        response.headers && emit({
          name: 'responseHeadersReceived',
          namespace: 'requestexecution',
          data: {
            id: info.id,
            responseHeaders: response.headers.toJSON()
          }
        });

        if (postmanCollectionSdk.CookieList.isCookieList(cookies)) {
          cookies = cookies.toJSON();
        } else {
          cookies = Array.isArray(cookies) ? cookies : [];
        }

        /**
         * The `request` event is called after the `responseStart` so during this interval
         * there will be no cookies to be shown in the UI.
         */
        emit({
          name: 'cookiesReceived',
          namespace: 'requestexecution',
          data: {
            id: info.id,
            cookies: cookies
          }
        });
      },

      response (err, cursor, response, request, item, cookies, history) {
        removeAborter(info.id);

        if (err) {
          // send the actual request that was sent over network when there is an error as in such cases
          // responseStart would not have been fired
          request && emit({
            name: 'requestDispatched',
            namespace: 'requestexecution',
            data: {
              id: info.id,
              request: request.toJSON(),
              requestSize: request.size()
            }
          });

          let error = new SerializedError(err);

          error.sessions = _.get(history, 'execution.sessions');

          emit({
            name: 'error',
            namespace: 'requestexecution',
            data: {
              id: info.id,
              cursor,
              error,
              phase: 'request'
            }
          });

          return;
        }

        if (!response) {
          return;
        }

        // There is a possibility that there are redirects in that case we will have multiple
        // timings, the last timing is the one that we need.
        let timings = _.last(_.get(history, 'execution.data')),
          responseContentInfo = _.isFunction(response.contentInfo) && response.contentInfo();

        timings = timings && timings.timings;

        // Send final meta information data about the response. At this point we know everything
        // about the response
        emit({
          name: 'responseFinalized',
          namespace: 'requestexecution',
          data: {
            id: info.id,
            meta: {
              responseSize: response.size(),
              responseTime: response.responseTime,
              timingPhases: postmanCollectionSdk.Response.timingPhases(timings)
            },
            responseContentInfo
          }
        });

        const responseBody = (
          info.truncateLargeResponse &&
          response.size().total > MAX_RESPONSE_SIZE
        ) ? { ___ignored___: 'Response body is too large' } : response.text();

        // TODO: Move task of response receiving to streaming model
        // Post that this callback will only signal the end of response
        emit({
          name: 'responseBodyReceived',
          namespace: 'requestexecution',
          data: {
            id: info.id,
            cursor,

            /**
             * WARN: At this point a copy of the stream is being made and persisted as a string.
             * This will cause 2x memory usage.
             * FUTURE: This is a trade-off that we need to accept at this moment as react could repeatedly
             * read this data
             */
            responseBody
          }
        });

        // send body stream
        emit({
          name: 'responseBodyStreamReceived',
          namespace: 'requestexecution',
          data: {
            id: info.id,

            /**
             * Passing the stream directly to IPC instead of converting it to JSON.
             *
             * WARNING: Historically response.steam.toJSON() was being used as encoded body would
             * have prevent from getting access to the raw stream if we want to write to image
             * files etc, but the conversion of stream to a JSON resulted in nearly 15x increase on heapMemory
             * consumption, therefore DO NOT CONVERT stream to json
             */
            responseBodyStream: response.stream
          }
        });

        // Save the response to a file as directed by the user
        // Note: The user will be asked to select the file he want the save the response. This is a blocking step.
        // TODO: Move the file section to before the request is sent
        if (info.download) {
          saveStreamToFile(responseContentInfo, response.stream, (err) => {
            emit({
              name: 'responseDownloaded',
              namespace: 'requestexecution',
              data: {
                id: info.id,
                error: err && (new SerializedError(err))
              }
            });
          });
        }
      },

      item (err, cursor, item, visualizerData) {
        if (err) {
          /**
           * Note: The error is not being handled here because currently Runtime always sends
           * null for error in this callback.
           *
           * @todo: Review this decision of not handling the error if runtime decides to
           * send any errors in this callback
           */
          pm.logger.info('RuntimeExecutionService~Error in item callback', err);
          return;
        }

        if (visualizerData) {
          visualizerData.error &&
            (visualizerData.error = new SerializedError(visualizerData.error));

          emit({
            name: 'visualizerDataReceived',
            namespace: 'requestexecution',
            data: {
              id: info.id,
              visualizerData: visualizerData
            }
          });
        }
      },

      pause (err) {
        emit({
          name: 'paused',
          namespace: 'requestexecution',
          data: {
            id: info.id,
            error: SerializedError(err)
          }
        });
      },

      resume (err) {
        emit({
          name: 'resumed',
          namespace: 'requestexecution',
          data: {
            id: info.id,
            error: SerializedError(err)
          }
        });
      },

      abort (err) {
        emit({
          name: 'aborted',
          namespace: 'requestexecution',
          data: {
            id: info.id,
            error: SerializedError(err)
          }
        });
      },

      stop (err) {
        emit({
          name: 'aborted',
          namespace: 'requestexecution',
          data: {
            id: info.id,
            error: SerializedError(err)
          }
        });
      },

      done (err) {
        const event = {
          name: 'finished',
          namespace: 'requestexecution',
          data: {
            id: info.id,
            error: err && new SerializedError(err)
          }
        };

        if (info.saveCookiesAfterRun && cookieJar && typeof cookieJar.updateStore === 'function') {
          // TODO - DECIDE on what to do with cookies when there was an error in done
          cookieJar.updateStore(() => {
            emit(event);
            disposeRun(info.id); // Note: We are not passing any handler for emit at its a natural termination
          });

          return;
        }

        emit(event);
        disposeRun(info.id); // Note: We are not passing any handler for emit at its a natural termination
      }
    });
  });
}

/**
 * @public
 * Get the auth manifest from runtime
 *
 * @returns {Object}
 */
function getAuthManifest () {
  const handlers = AuthLoader.handlers;


  return {
    name: 'fetchedAuthHandlers',
    namespace: 'requestauth',
    data: {
      authManifests: Object.keys(handlers).reduce((acc, authType) => {
        acc[authType] = handlers[authType].manifest;
        return acc;
      }, {})
    }
  };
}

/**
 * @public
 * LivePreview: Calling runtime's `dryRunRequest` to get previewed request
 *
 * @param {Request} request
 * @param {Object} info
 * @param {Object} options
 * @param {Function} cb
 */
function previewRequest (request, info = {}, options = {}, cb) {
  let requestToPreview = new postmanCollectionSdk.Request(request),
    dryRunOptions = _.pick(options, ['implicitCacheControl', 'implicitTraceHeader', 'protocolProfileBehavior']);

  options.cookiePartitionId && CookieJar &&
    (dryRunOptions.cookieJar = new CookieJar(options.cookiePartitionId, { readFromDB: true, writeToDB: false }));

  try {
    dryRunRequest(requestToPreview, dryRunOptions, (err, previewedRequest) => {
      if (err) {
        return cb({
          name: 'previewedRequest',
          namespace: 'requestpreview',
          data: { info, error: new SerializedError(err) }
        });
      }

      cb({
        name: 'previewedRequest',
        namespace: 'requestpreview',
        data: { info, previewedRequest: previewedRequest.toJSON() }
      });
    });
  }
  catch (e) {
    pm.logger.error('RuntimeExecutionService~previewRequest.dryRunRequest', e);
  }
}

/**
 * Checks if the given path is within the working directory
 */
function isInWorkingDir (workingDir, path) {
  return Boolean((new PostmanFs(workingDir))._resolve(path, []));
}

/**
 * Create Temporary File
 * @param name
 * @param content
 */
function createTemporaryFile (name, content, cb) {
  const basePath = app.getPath('temp'),
    tempFilePath = path.join(basePath, name);

  async.waterfall([
    // Attempt to clear the file if it already exists.
    // Note: We ignore the error here
    (next) => fs.unlink(tempFilePath, () => next()),

    // Write the contents of the temp directory
    (next) => fs.writeFile(tempFilePath, content, next)
  ], (err) => {
    cb(err && new SerializedError(err), tempFilePath);
  });
}

/**
 * Read file from filesystem
 * @param {String} id
 * @param {String} path
 */
function readFile (path, cb) {
  fs.readFile(path, (err, content) => {
    if (!err) {
      try {
        // From here on we will try detect the encoding and convert the buffer accordingly
        content = content.toString(detectEncoding(content));
      } catch (e) {
        err = new Error('Failed to detect encoding of the file content');
      }
    }

    return cb(err && new SerializedError(err), content);
  });
}

/**
 * Check if the given path has the required file-system access
 * @param {String} id
 * @param {String} path
 * @param {Boolean} writable
 */
function accessFile (path, writeable, cb) {
  const perm = writeable ? (fs.constants.R_OK | fs.constants.W_OK) : (fs.constants.R_OK);

  fs.access(path, perm, (err) => {
    cb(err && new SerializedError(err));
  });
}

/**
 * Handle CookieManager queries
 *
 * @param {String} method
 * @param {String} partitionId
 * @param {Object} options
 * @param {Function} cb
 */
function cookieHandler (method, partitionId, options, cb) {
  if (!(typeof CookieManager.prototype[method] === 'function' && partitionId && options)) {
    return cb(new TypeError('Illegal invocation'));
  }

  CookieManager.prototype[method].call({
    cookieStore: CookieManager.getCookieStore(partitionId)
  }, options, cb);
}

// #endregion

// We have two places that this is going to be used main process in electron and the we agent, hence we expose two API's here
module.exports = function () {
  /* native-ignore:start */ // IMPORTANT: Do not remove this comment. Used by webpack to ignore this section

  const postmanRuntime = require('postman-runtime');

  fs = require('fs');
  os = require('os');
  path = require('path');
  chardet = require('chardet');
  app = require('electron').app;
  dialog = require('electron').dialog;
  AuthLoader = require('postman-runtime/lib/authorizer').AuthLoader;
  sanitizeFilename = require('sanitize-filename');
  postmanCollectionSdk = require('postman-collection');
  SerializedError = require('serialised-error');

  // These are present in the main directory
  CookieJar = require('../../services/CookieJar');
  CookieManager = require('../../services/CookieManager');
  getSystemProxy = require('../../utils/getSystemProxy');

  PostmanFs = require('../utils/postmanFs'); // This is within the common folder

  collectionRunner = new postmanRuntime.Runner();
  dryRunRequest = postmanRuntime.Requester && postmanRuntime.Requester.dryRun;

  defaultWorkingDir = path.join(os.homedir(), 'Postman', 'files');

  isBrowser = false;


  // WARNING: Be very contingent of what is being exposed here. Some API's need native dependency that may not be available for the web
  // TODO: This needs a better api in-terms of DEPENDENCY INJECTION. Can be worked out alter to prevent bugs
  return {
    startRun,
    stopRun,
    pauseRun,
    resumeRun,
    getAuthManifest,
    previewRequest,

    // Only native
    isInWorkingDir,
    createTemporaryFile,
    readFile,
    accessFile,
    cookieHandler,
    defaultWorkingDir,
    saveStreamToFile
  };

  /* native-ignore:end */ // IMPORTANT: Do not remove this comment. Used by webpack to ignore this section
};


module.exports.Browser = async function () {
  const postmanRuntime = await import(/* webpackChunkName: "postman-runtime" */ 'postman-runtime/dist');
  // AuthLoader = require('postman-runtime/lib/authorizer').AuthLoader; // TODO: Decide what to do


  chardet = require('chardet');
  postmanCollectionSdk = require('postman-collection');
  SerializedError = require('serialised-error');

  collectionRunner = new postmanRuntime.Runner();
  dryRunRequest = postmanRuntime.Requester && postmanRuntime.Requester.dryRun;

  isBrowser = true;


  return {
    startRun,
    stopRun,
    pauseRun,
    resumeRun,

    // getAuthManifest,
    previewRequest,
    saveStreamToFile
  };
};
