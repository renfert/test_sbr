const { ipcMain } = require('electron');

/**
 * Agent interface to start listening and running
 */
function start (R, done) {
  ipcMain.on('runtime-ipc-command', (event, message) => {
    if (message.namespace === 'execution' && message.name === 'terminate') {
      R.stopRun(message.data.execution, (message) => {
        event.reply('runtime-ipc-event', message);
      });

      return;
    }

    if (message.name === 'execute') {
      R.startRun(message.data.info, message.data.collection, message.data.variables, message.data.options, (message) => {
        event.reply('runtime-ipc-event', message);
      });
      return;
    }

    if (message.namespace === 'execution' && message.name === 'pause') {
      R.pauseRun(message.data.execution, (message) => {
        event.reply('runtime-ipc-event', message);
      });
    }

    if (message.namespace === 'execution' && message.name === 'resume') {
      R.resumeRun(message.data.execution, (message) => {
        event.reply('runtime-ipc-event', message);
      });
    }

    if (message.name === 'loadAuthManifests') {
      event.reply('runtime-ipc-event', R.getAuthManifest());

      return;
    }

    if (message.name === 'previewRequest') {
      if (!message.data) {
        return;
      }

      const { request, info, options } = message.data;

      R.previewRequest(request, info, options, (message) => {
        event.reply('runtime-ipc-event', message);
      });

      return;
    }
  });

  ipcMain.handle('runtime-ipc-cb', async (e, event, fn, args) => {
    return new Promise((resolve) => {
      if (event === 'cookie') {
        return R.cookieHandler(fn, ...args, (err, result) => {
          resolve([err, result]);
        });
      }

      if (event === 'files' && fn === 'create-temp') {
        return R.createTemporaryFile(...args, (err, tempFilePath) => {
          resolve([err, tempFilePath]);
        });
      }

      if (event === 'files' && fn === 'read') {
        return R.readFile(...args, (err, content) => {
          resolve([err, content]);
        });
      }

      if (event === 'files' && fn === 'access') {
        return R.accessFile(...args, (err) => {
          resolve([err]);
        });
      }

      if (event === 'files' && fn === 'saveResponse') {
        return R.saveStreamToFile(...args, (err) => {
          resolve([err]);
        });
      }

      return resolve([]);
    });
  });

  ipcMain.on('postman-runtime-ipc-sync', (event, fn, args) => {
    if (fn === 'isInWorkingDir') {
      return event.returnValue = R.isInWorkingDir(...args);
    }
  });

  pm.logger.info('RuntimeIPCAgent~started: Success');

  done && done();
}

module.exports = { start };
