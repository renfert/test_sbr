webpackJsonp([19],{

/***/ 4705:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_mobx__ = __webpack_require__(8);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__constants_AppUrlConstants__ = __webpack_require__(60);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__stores_get_store__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__services_EditorService__ = __webpack_require__(54);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__external_navigation_ExternalNavigationService__ = __webpack_require__(53);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__constants_RequesterBottomPaneConstants__ = __webpack_require__(710);







let
PluginInterface = class PluginInterface {
  initialize() {
    this.properties = {
      layout: {
        value: Object(__WEBPACK_IMPORTED_MODULE_2__stores_get_store__["getStore"])('ConfigurationStore').get('editor.requestEditorLayoutName'),
        registerer: function (context, cb) {
          Object(__WEBPACK_IMPORTED_MODULE_0_mobx__["q" /* reaction */])(() => Object(__WEBPACK_IMPORTED_MODULE_2__stores_get_store__["getStore"])('ConfigurationStore').get('editor.requestEditorLayoutName'), cb.bind(context));
        } },

      theme: {
        value: pm.settings.getSetting('postmanTheme') || 'light',
        registerer: function (context, cb) {
          pm.settings.on('setSetting:postmanTheme', cb, context);
        } },

      platform: {
        value: navigator.platform,
        registerer: _.noop },

      windows: {
        value: [],
        registerer: function (context, cb) {
          pm.appWindow.on('windowClosed', cb.bind(context, 'windowClosed'), context);
        } },

      modals: {
        value: null,
        registerer: function (context, cb) {
          pm.mediator.on('modalOpened', cb.bind(context, 'modalOpened'), context);
          pm.mediator.on('modalClosed', cb.bind(context, 'modalClosed'), context);
        } },

      xFlows: {
        value: null,
        registerer: function (context, cb) {
          pm.mediator.on('saveXFlowActivity', cb.bind(context), context);
        } } };


  }

  register(property, handler, context) {
    this.properties[property] &&
    this.properties[property].registerer(context, handler);
  }

  get(key) {
    return _.get(this, `properties[${key}].value`);
  }

  openWindow(windowType) {
    switch (windowType) {
      case 'requester':
        pm.mediator.trigger('newRequesterWindow');
        break;
      case 'runner':
        pm.mediator.trigger('newRunnerWindow');
        break;
      case 'console':
        pm.mediator.trigger('newConsoleWindow');
        break;
      default:
        break;}

  }

  toggleTwoPaneLayout() {
    pm.app.toggleLayout();
  }

  openURL(url) {
    Object(__WEBPACK_IMPORTED_MODULE_4__external_navigation_ExternalNavigationService__["a" /* openExternalLink */])(url);
  }

  openModal(modalName, options) {
    switch (modalName) {
      case 'settings':
        pm.mediator.trigger('openSettingsModal', options.tab);
        break;
      case 'release-notes':
        __WEBPACK_IMPORTED_MODULE_3__services_EditorService__["a" /* default */].open('customview://releaseNotes');
        break;
      case 'x-flow-activity-feed':
        pm.mediator.trigger('openXFlowActivityFeed');
        break;
      default:
        break;}

  }

  toggleSidebar() {
    pm.mediator.trigger('toggleSidebar');
  }

  toggleFindReplace() {
    const store = Object(__WEBPACK_IMPORTED_MODULE_2__stores_get_store__["getStore"])('RequesterBottomPaneUIStore');

    store && store.toggleTab(__WEBPACK_IMPORTED_MODULE_5__constants_RequesterBottomPaneConstants__["a" /* REQUESTER_BOTTOM_PAME_FIND_REPLACE */]);
  }

  toggleConsole() {
    const store = Object(__WEBPACK_IMPORTED_MODULE_2__stores_get_store__["getStore"])('RequesterBottomPaneUIStore');

    store && store.toggleTab(__WEBPACK_IMPORTED_MODULE_5__constants_RequesterBottomPaneConstants__["b" /* REQUESTER_BOTTOM_PANE_CONSOLE */]);
  }};


/* harmony default export */ __webpack_exports__["a"] = (new PluginInterface());
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__(0)))

/***/ }),

/***/ 4707:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Text; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_classnames__ = __webpack_require__(7);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_classnames___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_classnames__);

let

Text = class Text extends __WEBPACK_IMPORTED_MODULE_0_react__["Component"] {
  constructor(props) {
    super(props);
  }

  getClasses() {
    return __WEBPACK_IMPORTED_MODULE_1_classnames___default()({ 'sb__item__text': true }, this.props.className);
  }

  render() {
    return (
      __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('div', { className: this.getClasses() },
        this.props.render && this.props.render()));


  }};

/***/ }),

/***/ 4708:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Icon; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_classnames__ = __webpack_require__(7);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_classnames___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_classnames__);

let

Icon = class Icon extends __WEBPACK_IMPORTED_MODULE_0_react__["Component"] {
  constructor(props) {
    super(props);
  }

  getClasses() {
    return __WEBPACK_IMPORTED_MODULE_1_classnames___default()({ 'sb__item__icon': true }, this.props.className);
  }

  render() {
    return (
      __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('div', {
          className: this.getClasses(),
          onClick: this.props.onClick,
          onMouseEnter: this.props.onMouseEnter,
          onMouseLeave: this.props.onMouseLeave },

        this.props.icon));


  }};

/***/ }),

/***/ 4709:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Pane; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_classnames__ = __webpack_require__(7);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_classnames___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_classnames__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__postman_react_draggable__ = __webpack_require__(367);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__postman_react_draggable___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2__postman_react_draggable__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__base_Icons_CloseIcon__ = __webpack_require__(79);



let


Pane = class Pane extends __WEBPACK_IMPORTED_MODULE_0_react__["Component"] {
  constructor(props) {
    super(props);
    this.state = { paneHeight: this.props.paneHeight || 200 };
    this.handleStart = this.handleStart.bind(this);
    this.handleDrag = this.handleDrag.bind(this);
  }

  UNSAFE_componentWillReceiveProps(nextProps) {
    if (nextProps.isOpen && nextProps.isOpen !== this.props.isOpen) {
      let documentHeight = _.get(document, 'body.offsetHeight', 800);
      if (documentHeight - this.state.paneHeight < 100) {
        this.setState({ paneHeight: documentHeight - 100 });
      }
    }
  }

  getClasses() {
    return __WEBPACK_IMPORTED_MODULE_1_classnames___default()({
      'sb__item__pane': true,
      'is-hidden': !this.props.isOpen },
    this.props.className);
  }

  handleStart(event, data) {
    this.paneHeight = this.state.paneHeight;
    this.startClientY = data.y;
  }

  handleDrag(event, data) {
    let clientY = data.y,
    paneHeight = this.paneHeight + (this.startClientY - clientY),
    documentHeight = _.get(document, 'body.offsetHeight', 800);

    if (documentHeight - paneHeight < 100) {
      paneHeight = this.state.paneHeight;
    }

    if (paneHeight < 100) {
      paneHeight = 100;
    }

    this.setState({ paneHeight: paneHeight });
  }

  render() {
    return (
      __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__postman_react_draggable__["DraggableCore"], {
          axis: 'y',
          handle: '.plugin__pane-resize-wrapper',
          onStart: this.handleStart,
          onDrag: this.handleDrag },

        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('div', {
            className: this.getClasses(),
            style: { 'height': this.state.paneHeight } },

          __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('div', { className: 'plugin__pane-resize-wrapper' }),
          this.props.children,
          __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__base_Icons_CloseIcon__["a" /* default */], {
            className: 'plugin__pane-close',
            onClick: this.props.onClose }))));




  }};
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__(0)))

/***/ }),

/***/ 4710:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Drawer; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__base_Dropdowns__ = __webpack_require__(24);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_classnames__ = __webpack_require__(7);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_classnames___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_classnames__);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};

let

Drawer = class Drawer extends __WEBPACK_IMPORTED_MODULE_0_react__["Component"] {
  constructor(props) {
    super(props);

    this.handleSelect = this.handleSelect.bind(this);
  }

  handleSelect(item) {
    this.props.onSelect && this.props.onSelect(item);
  }

  getClasses() {
    return __WEBPACK_IMPORTED_MODULE_2_classnames___default()({ 'sb__drawer': true }, this.props.className);
  }

  getItemProps(defaultArgs, props = {}) {
    return _extends({},
    defaultArgs,
    props, {
      className: __WEBPACK_IMPORTED_MODULE_2_classnames___default()(defaultArgs.className, props.className || '') });

  }

  render() {
    return (
      __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('div', { className: this.getClasses() },
        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__base_Dropdowns__["a" /* Dropdown */], { onSelect: this.handleSelect },
          __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__base_Dropdowns__["b" /* DropdownButton */], null,
            this.props.button && this.props.button()),

          __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__base_Dropdowns__["c" /* DropdownMenu */], { 'align-right': true },

            _.map(this.props.items, item => {
              return (
                __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__base_Dropdowns__["d" /* MenuItem */], {
                    key: item.key,
                    refKey: item.key },

                  __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span', null, item.label)));


            })))));





  }};


Drawer.defaultProps = {
  itemRenderer: (item, getItemProps) => {
    return (
      __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('div', getItemProps(),
        item.label));


  } };
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__(0)))

/***/ }),

/***/ 5664:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* WEBPACK VAR INJECTION */(function(_) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return StatusBarContainer; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_mobx_react__ = __webpack_require__(4);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__models_status_bar_StatusBar__ = __webpack_require__(5665);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__components_status_bar_plugins__ = __webpack_require__(5666);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__plugins_PluginInterface__ = __webpack_require__(4705);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__components_status_bar_base_Item__ = __webpack_require__(5680);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__components_status_bar_base_Text__ = __webpack_require__(4707);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__components_status_bar_base_Icon__ = __webpack_require__(4708);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__components_status_bar_base_Pane__ = __webpack_require__(4709);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__components_status_bar_base_Drawer__ = __webpack_require__(4710);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__constants_RequesterTabLayoutConstants__ = __webpack_require__(128);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__components_base_XPaths_XPath__ = __webpack_require__(20);
var _class;















let PluginEnvironment = {
  React: __WEBPACK_IMPORTED_MODULE_0_react___default.a,
  PluginInterface: __WEBPACK_IMPORTED_MODULE_4__plugins_PluginInterface__["a" /* default */],
  StatusBarComponents: {
    Item: __WEBPACK_IMPORTED_MODULE_5__components_status_bar_base_Item__["a" /* default */],
    Text: __WEBPACK_IMPORTED_MODULE_6__components_status_bar_base_Text__["a" /* default */],
    Icon: __WEBPACK_IMPORTED_MODULE_7__components_status_bar_base_Icon__["a" /* default */],
    Pane: __WEBPACK_IMPORTED_MODULE_8__components_status_bar_base_Pane__["a" /* default */],
    Drawer: __WEBPACK_IMPORTED_MODULE_9__components_status_bar_base_Drawer__["a" /* default */] },

  constants: {
    layout: {
      REQUESTER_TAB_LAYOUT_1_COLUMN: __WEBPACK_IMPORTED_MODULE_10__constants_RequesterTabLayoutConstants__["b" /* REQUESTER_TAB_LAYOUT_1_COLUMN */],
      REQUESTER_TAB_LAYOUT_2_COLUMN: __WEBPACK_IMPORTED_MODULE_10__constants_RequesterTabLayoutConstants__["c" /* REQUESTER_TAB_LAYOUT_2_COLUMN */] } } };let





StatusBarContainer = Object(__WEBPACK_IMPORTED_MODULE_1_mobx_react__["b" /* observer */])(_class = class StatusBarContainer extends __WEBPACK_IMPORTED_MODULE_0_react__["Component"] {
  constructor(props) {
    super(props);

    this.state = {
      items: [],
      activeItem: null };


    this.addItem = this.addItem.bind(this);
    this.addItems = this.addItems.bind(this);
    this.toggleActive = this.toggleActive.bind(this);
    this.items = null;
  }

  componentDidMount() {
    __WEBPACK_IMPORTED_MODULE_2__models_status_bar_StatusBar__["a" /* default */].initialize();
    __WEBPACK_IMPORTED_MODULE_2__models_status_bar_StatusBar__["a" /* default */].loadPlugins(__WEBPACK_IMPORTED_MODULE_3__components_status_bar_plugins__["a" /* default */]);
  }

  UNSAFE_componentWillMount() {
    __WEBPACK_IMPORTED_MODULE_2__models_status_bar_StatusBar__["a" /* default */].on('loadedPlugins', this.addItems);
    __WEBPACK_IMPORTED_MODULE_2__models_status_bar_StatusBar__["a" /* default */].on('add', this.addItem);
  }

  componentWillUnmount() {
    __WEBPACK_IMPORTED_MODULE_2__models_status_bar_StatusBar__["a" /* default */].off('loadedPlugins', this.addItems);
    __WEBPACK_IMPORTED_MODULE_2__models_status_bar_StatusBar__["a" /* default */].off('add', this.addItem);
    this.items = null;
  }

  addItem(item) {
    this.items.push({
      item: item,
      component: item.getComponent(PluginEnvironment) });

    let items = _.concat(this.state.items, item);
    this.setState({ items });
  }

  addItems(items) {
    this.items = _.map(__WEBPACK_IMPORTED_MODULE_3__components_status_bar_plugins__["a" /* default */], item => {
      return {
        item: item,
        component: item.getComponent(PluginEnvironment) };

    });
    this.setState({ items });
  }

  toggleActive(item) {
    this.setState({ activeItem: this.state.activeItem === item ? null : item });
  }

  render() {
    return (
      __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_11__components_base_XPaths_XPath__["a" /* default */], { identifier: 'statusBar' },
        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('div', { className: 'status-bar-container status-bar' },
          __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('div', { className: 'sb-section' },

            _.map(this.items, (item, index) => {
              return __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(item.component, {
                key: index,
                isOpen: _.isEqual(this.state.activeItem, item.item.name),
                toggleActive: this.toggleActive.bind(this, item.item.name) });

            })))));





  }}) || _class;
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__(0)))

/***/ }),

/***/ 5665:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_events__ = __webpack_require__(37);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_events___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_events__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__plugins_PluginInterface__ = __webpack_require__(4705);

let

StatusBar = class StatusBar extends __WEBPACK_IMPORTED_MODULE_0_events___default.a {
  constructor() {
    super();
  }

  initialize() {
    __WEBPACK_IMPORTED_MODULE_1__plugins_PluginInterface__["a" /* default */].initialize();
  }

  register(property, handler, context) {
    this.properties[property] &&
    this.properties[property].handler(context, handler);
  }

  loadPlugins(plugins) {
    this.emit('loadedPlugins', plugins);
  }

  addItem(sbItem) {
    this.emit('add', sbItem);
    sbItem.initialize && sbItem.initialize();
  }};


/* harmony default export */ __webpack_exports__["a"] = (new StatusBar());

/***/ }),

/***/ 5666:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__Help__ = __webpack_require__(5667);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__ShortcutsReference__ = __webpack_require__(5669);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__TwoPane__ = __webpack_require__(5671);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__ToggleSidebar__ = __webpack_require__(5674);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__WorkspaceTypeSwitcher__ = __webpack_require__(5676);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__onboarding_src_features_Skills_Bootcamp_components_BootcampLauncher__ = __webpack_require__(5677);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__AgentSelection__ = __webpack_require__(5678);








/* harmony default export */ __webpack_exports__["a"] = ([
__WEBPACK_IMPORTED_MODULE_0__Help__["a" /* default */],
__WEBPACK_IMPORTED_MODULE_1__ShortcutsReference__["a" /* default */],
__WEBPACK_IMPORTED_MODULE_2__TwoPane__["a" /* default */],
__WEBPACK_IMPORTED_MODULE_3__ToggleSidebar__["a" /* default */],
__WEBPACK_IMPORTED_MODULE_6__AgentSelection__["a" /* default */],
__WEBPACK_IMPORTED_MODULE_4__WorkspaceTypeSwitcher__["a" /* default */],
__WEBPACK_IMPORTED_MODULE_5__onboarding_src_features_Skills_Bootcamp_components_BootcampLauncher__["a" /* default */]]);

/***/ }),

/***/ 5667:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_base_Icons_HelpIcon__ = __webpack_require__(5668);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__constants_AppUrlConstants__ = __webpack_require__(60);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};


/* harmony default export */ __webpack_exports__["a"] = ({
  name: 'Help',
  position: 'right',

  getComponent: function ({
    React,
    PluginInterface,
    StatusBarComponents })
  {let
    Help = class Help extends React.Component {
      constructor(props) {
        super(props);
      }

      handleItemSelect(item) {
        switch (item) {
          case 'releases':
            PluginInterface.openModal('release-notes');
            break;
          case 'docs':
            PluginInterface.openURL(__WEBPACK_IMPORTED_MODULE_1__constants_AppUrlConstants__["y" /* DOCS_URL */]);
            break;
          case 'security':
            PluginInterface.openURL(__WEBPACK_IMPORTED_MODULE_1__constants_AppUrlConstants__["x" /* DOCS_SECURITY_URL */]);
            break;
          case 'support':
            PluginInterface.openURL(__WEBPACK_IMPORTED_MODULE_1__constants_AppUrlConstants__["_14" /* SUPPORT_URL */]);
            break;
          case 'twitter':
            PluginInterface.openURL(__WEBPACK_IMPORTED_MODULE_1__constants_AppUrlConstants__["_21" /* TWITTER_URL */]);
            break;
          case 'community':
            PluginInterface.openURL(__WEBPACK_IMPORTED_MODULE_1__constants_AppUrlConstants__["_0" /* POSTMAN_COMMUNITY */]);
            break;
          default:
            break;}

      }

      getIcon() {
        return (
          React.createElement(__WEBPACK_IMPORTED_MODULE_0__components_base_Icons_HelpIcon__["a" /* default */], null));

      }

      render() {
        let { Item, Icon, Drawer } = StatusBarComponents;

        return (
          React.createElement(Item, _extends({
              className: 'plugin__help',
              tooltip: 'Help & Feedback' },
            this.props),

            React.createElement(Drawer, {
              className: 'plugin__help__drawer',
              button: () => {
                return (
                  React.createElement(Icon, {
                    className: 'plugin__help__icon',
                    icon: this.getIcon() }));


              },
              onSelect: this.handleItemSelect,
              items: [
              {
                key: 'releases',
                label: 'Release Notes' },

              {
                key: 'docs',
                label: 'Documentation' },

              {
                key: 'security',
                label: 'Security' },

              {
                key: 'support',
                label: 'Support' },

              {
                key: 'twitter',
                label: '@getpostman' },

              {
                key: 'community',
                label: 'Community' }] })));





      }};


    return Help;
  } });

/***/ }),

/***/ 5668:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = HelpIcon;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__Icon__ = __webpack_require__(15);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};


const icon =
__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('svg', { width: '16', height: '16', viewBox: '0 0 16 16' },
  __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('defs', null,
    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('path', { id: 'help', d: 'M8 16A8 8 0 1 1 8 0a8 8 0 0 1 0 16zm0-1A7 7 0 1 0 8 1a7 7 0 0 0 0 14zM6.715 5.054a.622.622 0 1 1-1.143-.5A2.581 2.581 0 0 1 7.94 3a2.586 2.586 0 0 1 2.581 2.59c0 .864-.583 1.588-1.642 2.19a.625.625 0 0 0-.316.543V9.79a.624.624 0 1 1-1.246 0V8.323c0-.675.362-1.298.947-1.63.71-.404 1.01-.778 1.01-1.104a1.335 1.335 0 1 0-2.56-.536zm.6 7.321a.624.624 0 1 0 1.249.002.624.624 0 0 0-1.248-.002z' })),

  __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('use', { fill: '#666', fillRule: 'nonzero', xlinkHref: '#help' }));



function HelpIcon(props) {
  return (
    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__Icon__["a" /* default */], _extends({},
    props, {
      icon: icon })));


}

/***/ }),

/***/ 5669:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_base_Icons_KeyboardShortcutIcon__ = __webpack_require__(5670);


/* harmony default export */ __webpack_exports__["a"] = ({
  name: 'Shortcuts',
  position: 'right',

  getComponent: function ({
    React,
    PluginInterface,
    StatusBarComponents })
  {
    return class ShortcutsReference extends React.Component {
      constructor(props) {
        super(props);

        this.state = { isModalOpen: false };
      }

      UNSAFE_componentWillMount() {
        PluginInterface.register('modals', this.handleModalState, this);
      }

      handleClick() {
        PluginInterface.openModal('settings', { tab: 'shortcuts' });
      }

      handleModalState(event, payload) {
        if (event === 'modalOpened' && payload.name === 'settings' && payload.activeTab === 'shortcuts') {
          this.setState({ isModalOpen: true });
        } else
        if (event === 'modalOpened' && payload.name === 'settings') {
          this.setState({ isModalOpen: false });
        } else
        if (event === 'modalClosed' && payload.name === 'settings') {
          this.setState({ isModalOpen: false });
        }
      }

      getIcon() {
        let style = this.state.isModalOpen ? 'secondary' : 'normal';

        return (
          React.createElement(__WEBPACK_IMPORTED_MODULE_0__components_base_Icons_KeyboardShortcutIcon__["a" /* default */], { style: style }));

      }

      getShortcut() {
        let platform = PluginInterface.get('platform');
        if (_.includes(platform, 'Mac')) {
          return '⌘?';
        } else
        {
          return 'Ctrl + ?';
        }
      }

      render() {
        let { Item, Icon } = StatusBarComponents;

        return (
          React.createElement(Item, {
              className: 'plugin__shortcuts',
              tooltip: `Keyboard Shortcuts (${this.getShortcut()})` },

            React.createElement(Icon, {
              onClick: this.handleClick,
              className: 'plugin__shortcuts__icon',
              icon: this.getIcon() })));



      }};

  } });
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__(0)))

/***/ }),

/***/ 5670:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = KeyboardShortcutIcon;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__Icon__ = __webpack_require__(15);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__XPaths_XPath__ = __webpack_require__(20);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};



const icon =
__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('svg', { width: '15', height: '16', viewBox: '0 0 16 16' },
  __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('defs', null,
    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('path', { id: 'keyboard-shortcut', d: 'M7.1 7V2.687c0-.455-.414-.843-.934-.843-.519 0-.932.388-.932.843v.751c0 .989-.846 1.781-1.868 1.781-1.02 0-1.866-.792-1.866-1.781V.5a.5.5 0 0 1 1 0v2.938c0 .421.384.781.866.781.484 0 .868-.36.868-.781v-.751c0-1.023.875-1.843 1.932-1.843 1.059 0 1.934.82 1.934 1.843V7H15v9H0V7h7.1zM1 15h13V8H1v7zm1-6h1v1H2V9zm2 0h1v1H4V9zm2 0h1v1H6V9zm2 0h1v1H8V9zm2 0h1v1h-1V9zm2 0h1v1h-1V9zM2 11h1v1H2v-1zm1 2h1v1H3v-1zm1-2h1v1H4v-1zm2 0h1v1H6v-1zm2 0h1v1H8v-1zm2 0h1v1h-1v-1zm2 0h1v1h-1v-1zm-1 2h1v1h-1v-1zm-6 0h5v1H5v-1z' })),

  __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('use', { fill: 'gray', fillRule: 'evenodd', xlinkHref: '#keyboard-shortcut' }));



function KeyboardShortcutIcon(props) {
  return (
    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__XPaths_XPath__["a" /* default */], { identifier: 'shortcuts' },
      __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__Icon__["a" /* default */], _extends({},
      props, {
        icon: icon }))));



}

/***/ }),

/***/ 5671:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_base_Icons_TwoPaneIcon__ = __webpack_require__(5672);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__components_base_Icons_SinglePaneIcon__ = __webpack_require__(5673);



/* harmony default export */ __webpack_exports__["a"] = ({
  name: 'TwoPane',
  position: 'right',

  getComponent: function ({
    React,
    PluginInterface,
    StatusBarComponents,
    constants })
  {
    return class TwoPane extends React.Component {
      constructor(props) {
        super(props);

        this.state = { layout: PluginInterface.get('layout') };
      }

      UNSAFE_componentWillMount() {
        PluginInterface.register('layout', this.handleLayout, this);
      }

      handleLayout(payload) {
        this.setState({ layout: payload });
      }

      handleClick() {
        PluginInterface.toggleTwoPaneLayout();
      }

      getShortcut() {
        let platform = PluginInterface.get('platform');
        if (_.includes(platform, 'Mac')) {
          return '⌥⌘V';
        } else
        {
          return 'Ctrl + Alt + V';
        }
      }

      getIcon() {
        let activeTheme = PluginInterface.get('theme'),
        layout = this.state.layout,
        { REQUESTER_TAB_LAYOUT_1_COLUMN, REQUESTER_TAB_LAYOUT_2_COLUMN } = constants.layout;

        if (_.isEqual(layout, REQUESTER_TAB_LAYOUT_2_COLUMN)) {
          return (
            React.createElement(__WEBPACK_IMPORTED_MODULE_1__components_base_Icons_SinglePaneIcon__["a" /* default */], null));

        } else
        {
          return (
            React.createElement(__WEBPACK_IMPORTED_MODULE_0__components_base_Icons_TwoPaneIcon__["a" /* default */], null));

        }
      }

      render() {
        let { Item, Icon } = StatusBarComponents,
        { REQUESTER_TAB_LAYOUT_2_COLUMN } = constants.layout,
        isTwoPane = this.state.layout === REQUESTER_TAB_LAYOUT_2_COLUMN;

        return (
          React.createElement(Item, {
              className: `plugin__layout ${isTwoPane ? 'singlePane' : 'twoPane'}`,
              tooltip: `${isTwoPane ? 'Single pane view' : 'Two pane view'} (${this.getShortcut()})` },

            React.createElement(Icon, {
              onClick: this.handleClick,
              icon: this.getIcon() })));



      }};

  } });
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__(0)))

/***/ }),

/***/ 5672:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = TwoPaneIcon;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__Icon__ = __webpack_require__(15);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__XPaths_XPath__ = __webpack_require__(20);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};



const icon =
__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('svg', { width: '16', height: '16', viewBox: '0 0 16 16' },
  __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('defs', null,
    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('path', { id: 'two-pane', d: 'M7.5 1H1v14h6.521a.974.974 0 0 1-.021-.205V1zm1 0v13.795c0 .072-.007.14-.021.205H15V1H8.5zM15 0a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1V1a1 1 0 0 1 1-1h14zM2.25 10V6h4v4h-4zm9.5 0a2 2 0 1 1 0-4 2 2 0 0 1 0 4z' })),

  __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('use', { fill: 'gray', fillRule: 'evenodd', xlinkHref: '#two-pane' }));



function TwoPaneIcon(props) {
  return (
    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__XPaths_XPath__["a" /* default */], { identifier: 'layout' },
      __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__Icon__["a" /* default */], _extends({},
      props, {
        icon: icon }))));



}

/***/ }),

/***/ 5673:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = SinglePaneIcon;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__Icon__ = __webpack_require__(15);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__XPaths_XPath__ = __webpack_require__(20);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};



const icon =
__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('svg', { width: '16', height: '16', viewBox: '0 0 16 16' },
  __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('defs', null,
    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('path', { id: 'single-pane', d: 'M7.5 1H1v14h6.521a.974.974 0 0 1-.021-.205V1zm1 0v13.795c0 .072-.007.14-.021.205H15V1H8.5zM15 0a1 1 0 0 1 1 1v14a1 1 0 0 1-1 1H1a1 1 0 0 1-1-1V1a1 1 0 0 1 1-1h14zM2.25 10V6h4v4h-4zm9.5 0a2 2 0 1 1 0-4 2 2 0 0 1 0 4z' })),

  __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('use', { fill: 'gray', fillRule: 'evenodd', transform: 'rotate(90 8 8)', xlinkHref: '#single-pane' }));



function SinglePaneIcon(props) {
  return (
    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__XPaths_XPath__["a" /* default */], { identifier: 'layout' },
      __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__Icon__["a" /* default */], _extends({},
      props, {
        icon: icon }))));



}

/***/ }),

/***/ 5674:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__components_base_Icons_SidebarShowIcon__ = __webpack_require__(5675);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__stores_get_store__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_mobx_react__ = __webpack_require__(4);





/* harmony default export */ __webpack_exports__["a"] = ({
  name: 'ToggleSidebar',
  position: 'left',

  getComponent: function ({
    React,
    PluginInterface,
    StatusBarComponents })
  {var _class;
    return Object(__WEBPACK_IMPORTED_MODULE_2_mobx_react__["b" /* observer */])(_class = class ToggleSidebar extends React.Component {
      constructor(props) {
        super(props);

        this.handleClick = this.handleClick.bind(this);
      }

      handleClick() {
        PluginInterface.toggleSidebar();
      }

      getIcon(isOpen) {
        let style = isOpen ? 'secondary' : 'normal';

        return (
          React.createElement(__WEBPACK_IMPORTED_MODULE_0__components_base_Icons_SidebarShowIcon__["a" /* default */], { style: style }));

      }

      getShortcut() {
        let platform = PluginInterface.get('platform');
        if (_.includes(platform, 'Mac')) {
          return '⌘\\';
        } else
        {
          return 'Ctrl + \\';
        }
      }

      render() {
        let { Item, Icon } = StatusBarComponents;
        let isOpen = Object(__WEBPACK_IMPORTED_MODULE_1__stores_get_store__["getStore"])('RequesterSidebarStore').isOpen;

        return (
          React.createElement(Item, {
              className: 'plugin__sidebar-shortcut',
              tooltip: `${isOpen ? 'Hide' : 'Show'} Sidebar (${this.getShortcut()})` },

            React.createElement(Icon, {
              onClick: this.handleClick,
              className: 'plugin__sidebar__icon',
              icon: this.getIcon(isOpen) })));



      }}) || _class;

  } });
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__(0)))

/***/ }),

/***/ 5675:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = SidebarShowIcon;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__Icon__ = __webpack_require__(15);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__XPaths_XPath__ = __webpack_require__(20);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};



const icon =
__WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('svg', { width: '16', height: '14', viewBox: '0 0 16 16' },
  __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('defs', null,
    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('path', { id: 'sidebar-show', d: 'M7 2H1.433A.433.433 0 0 0 1 2.434v11.132c0 .24.194.434.433.434H7V2zm1 0v12h6.567c.24 0 .433-.194.433-.434V2.434A.433.433 0 0 0 14.567 2H8zM6 5v1H2V5h4zm0-1H2V3h4v1zm0 3v1H2V7h4zm0 2v1H2V9h4zm0 2v1H2v-1h4zM1.324 1h13.352C15.407 1 16 1.593 16 2.324v11.352c0 .731-.593 1.324-1.324 1.324H1.324A1.324 1.324 0 0 1 0 13.676V2.324C0 1.593.593 1 1.324 1z' })),

  __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('use', { fill: 'gray', fillRule: 'evenodd', xlinkHref: '#sidebar-show' }));



function SidebarShowIcon(props) {
  return (
    __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_2__XPaths_XPath__["a" /* default */], { identifier: 'sidebar' },
      __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_1__Icon__["a" /* default */], _extends({},
      props, {
        icon: icon }))));



}

/***/ }),

/***/ 5676:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__constants_RequesterTabConstants__ = __webpack_require__(235);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__stores_get_store__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_mobx_react__ = __webpack_require__(4);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_mobx__ = __webpack_require__(8);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_classnames__ = __webpack_require__(7);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_classnames___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_classnames__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__modules_services_AnalyticsService__ = __webpack_require__(16);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__services_WorkspaceViewModeService__ = __webpack_require__(1291);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__constants_AppUrlConstants_js__ = __webpack_require__(60);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__WorkspaceTypeSwitcherIntro__ = __webpack_require__(4675);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__TypeSwitcher__ = __webpack_require__(4333);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__external_navigation_ExternalNavigationService__ = __webpack_require__(53);
var _extends = Object.assign || function (target) {for (var i = 1; i < arguments.length; i++) {var source = arguments[i];for (var key in source) {if (Object.prototype.hasOwnProperty.call(source, key)) {target[key] = source[key];}}}return target;};











const labelMap = {
  [__WEBPACK_IMPORTED_MODULE_0__constants_RequesterTabConstants__["b" /* WORKSPACE_BUILDER_VIEW */]]: 'Build',
  [__WEBPACK_IMPORTED_MODULE_0__constants_RequesterTabConstants__["a" /* WORKSPACE_BROWSER_VIEW */]]: 'Browse' };


/* harmony default export */ __webpack_exports__["a"] = ({
  name: 'WorkspaceViewSwitcher',
  position: 'right',

  getComponent: function ({
    React,
    PluginInterface,
    StatusBarComponents })
  {let
    WorkspaceTypeSwitcher = class WorkspaceTypeSwitcher extends React.Component {
      constructor(props) {
        super(props);

        this.state = { showTooltip: false };

        this.handleItemSelect = this.handleItemSelect.bind(this);
        this.handleHideTooptip = this.handleHideTooptip.bind(this);
        this.handleShowTooltip = this.handleShowTooltip.bind(this);
        this.handleLearnMore = this.handleLearnMore.bind(this);
      }

      UNSAFE_componentWillMount() {
        this.viewModeReaction = Object(__WEBPACK_IMPORTED_MODULE_3_mobx__["q" /* reaction */])(() => Object(__WEBPACK_IMPORTED_MODULE_1__stores_get_store__["getStore"])('ActiveWorkspaceSessionStore').viewMode, viewMode => {
          if (viewMode === __WEBPACK_IMPORTED_MODULE_0__constants_RequesterTabConstants__["a" /* WORKSPACE_BROWSER_VIEW */]) {
            this.handleShowTooltip();
          }
        });
      }

      componentWillUnmount() {
        this.viewModeReaction();
      }

      handleHideTooptip() {
        this.setState({ showTooltip: false });
        pm.settings.setSetting('showWorkspaceTypeSwitcherIntro', false);
      }

      handleShowTooltip() {
        this.setState({ showTooltip: _.isUndefined(pm.settings.getSetting('showWorkspaceTypeSwitcherIntro')) ? true : pm.settings.getSetting('showWorkspaceTypeSwitcherIntro') });
      }

      handleLearnMore() {
        Object(__WEBPACK_IMPORTED_MODULE_10__external_navigation_ExternalNavigationService__["a" /* openExternalLink */])(__WEBPACK_IMPORTED_MODULE_7__constants_AppUrlConstants_js__["p" /* BROWSING_A_WORKSPACE_DOCS */]);
      }

      handleItemSelect(item) {
        this.handleHideTooptip();

        if (item === Object(__WEBPACK_IMPORTED_MODULE_1__stores_get_store__["getStore"])('ActiveWorkspaceSessionStore').viewMode) {
          return;
        } else
        if (item === __WEBPACK_IMPORTED_MODULE_0__constants_RequesterTabConstants__["a" /* WORKSPACE_BROWSER_VIEW */]) {
          __WEBPACK_IMPORTED_MODULE_5__modules_services_AnalyticsService__["a" /* default */].addEvent('workspace', 'switch_view', 'browse');
          __WEBPACK_IMPORTED_MODULE_6__services_WorkspaceViewModeService__["a" /* default */].openBrowseMode();
        } else
        if (item === __WEBPACK_IMPORTED_MODULE_0__constants_RequesterTabConstants__["b" /* WORKSPACE_BUILDER_VIEW */]) {
          if (!Object(__WEBPACK_IMPORTED_MODULE_1__stores_get_store__["getStore"])('ActiveBrowseWorkspaceStore').isMember) {
            pm.mediator.trigger('joinWorkspace');
            return;
          }
          __WEBPACK_IMPORTED_MODULE_5__modules_services_AnalyticsService__["a" /* default */].addEvent('workspace', 'switch_view', 'build');
          __WEBPACK_IMPORTED_MODULE_6__services_WorkspaceViewModeService__["a" /* default */].openBuildMode();
        }

      }

      getSwitchClasses(viewMode) {
        return __WEBPACK_IMPORTED_MODULE_4_classnames___default()({
          'plugin__workspace-view-switcher__switch': true,
          left: viewMode === __WEBPACK_IMPORTED_MODULE_0__constants_RequesterTabConstants__["b" /* WORKSPACE_BUILDER_VIEW */],
          right: viewMode === __WEBPACK_IMPORTED_MODULE_0__constants_RequesterTabConstants__["a" /* WORKSPACE_BROWSER_VIEW */] });

      }

      render() {
        let { Item, Text } = StatusBarComponents;
        if (!Object(__WEBPACK_IMPORTED_MODULE_1__stores_get_store__["getStore"])('CurrentUserStore').isLoggedIn) {
          return false;
        }

        let viewMode = Object(__WEBPACK_IMPORTED_MODULE_1__stores_get_store__["getStore"])('ActiveWorkspaceSessionStore').viewMode;
        return (
          React.createElement('div', null,
            React.createElement(Item, _extends({
                className: 'plugin__workspace-view-switcher',
                tooltip: 'Switch workspace view',
                ref: 'tooltip_button' },
              this.props),

              React.createElement(Text, {
                render: () => {
                  return (
                    React.createElement(__WEBPACK_IMPORTED_MODULE_9__TypeSwitcher__["a" /* default */], {
                      activeItem: viewMode,
                      onSelect: this.handleItemSelect,
                      items: [
                      {
                        key: __WEBPACK_IMPORTED_MODULE_0__constants_RequesterTabConstants__["b" /* WORKSPACE_BUILDER_VIEW */],
                        label: 'Build',
                        position: 'left' },

                      {
                        key: __WEBPACK_IMPORTED_MODULE_0__constants_RequesterTabConstants__["a" /* WORKSPACE_BROWSER_VIEW */],
                        label: 'Browse',
                        position: 'right' }] }));




                } })),


            React.createElement(__WEBPACK_IMPORTED_MODULE_8__WorkspaceTypeSwitcherIntro__["a" /* default */], {
              show: this.state.showTooltip,
              target: this.refs.tooltip_button,
              onHide: this.handleHideTooptip,
              onLearnMore: this.handleLearnMore })));




      }};


    return Object(__WEBPACK_IMPORTED_MODULE_2_mobx_react__["b" /* observer */])(WorkspaceTypeSwitcher);
  } });
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__(0)))

/***/ }),

/***/ 5677:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* WEBPACK VAR INJECTION */(function(_) {/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_classnames__ = __webpack_require__(7);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_classnames___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_classnames__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__LessonConstants__ = __webpack_require__(1310);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__common_APIService__ = __webpack_require__(372);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__LessonController__ = __webpack_require__(961);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__common_dependencies__ = __webpack_require__(40);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__js_components_base_XPaths_XPath__ = __webpack_require__(20);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__js_components_base_Icons_BootcampIcon__ = __webpack_require__(1893);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__js_components_base_Icons_CloseIcon__ = __webpack_require__(79);













const defaultState = {
  dismissable: false,
  currentState: null,
  label: 'Bootcamp',
  pausedLessonId: null },

HIGHLIGHT_STATE = 'highlight',
SUCCESS_STATE = 'success';

/* harmony default export */ __webpack_exports__["a"] = ({
  name: 'learningCenter',
  position: 'right',

  getComponent: function ({
    React,
    StatusBarComponents })
  {
    return class LearningCenter extends React.Component {
      constructor(props) {
        super(props);
        this.state = defaultState;

        this.handleReset = this.handleReset.bind(this);
        this.handleContinue = this.handleContinue.bind(this);
        this.handleClick = this.handleClick.bind(this);
        this.handleHighlightLessonButton = this.handleHighlightLessonButton.bind(this);
        __WEBPACK_IMPORTED_MODULE_4__common_dependencies__["p" /* UIEventService */].subscribe(__WEBPACK_IMPORTED_MODULE_1__LessonConstants__["b" /* LESSON_PAUSED */], this.handleContinue);
        __WEBPACK_IMPORTED_MODULE_4__common_dependencies__["p" /* UIEventService */].subscribe('highlightLessonButton', this.handleHighlightLessonButton);
        __WEBPACK_IMPORTED_MODULE_4__common_dependencies__["p" /* UIEventService */].subscribe(__WEBPACK_IMPORTED_MODULE_4__common_dependencies__["k" /* OPEN_LESSON_PLAN */], this.openBootcampTab);
      }

      openBootcampTab() {
        __WEBPACK_IMPORTED_MODULE_4__common_dependencies__["g" /* EditorService */].open('customView://bootcamp', { preview: false });
      }

      continuePausedLesson() {
        Object(__WEBPACK_IMPORTED_MODULE_2__common_APIService__["b" /* fetchLesson */])(this.state.pausedLessonId, lesson => {
          if (_.isEmpty(lesson)) {
            return;
          }
          __WEBPACK_IMPORTED_MODULE_3__LessonController__["a" /* default */].continueLesson(lesson);
        });
        this.handleReset();
      }

      handleClick() {
        if (this.state.pausedLessonId) {
          this.continuePausedLesson();
          return;
        }
        let currentUser = Object(__WEBPACK_IMPORTED_MODULE_4__common_dependencies__["A" /* getStore */])('CurrentUserStore'),
        isLoggedIn = currentUser && currentUser.isLoggedIn;

        if (!isLoggedIn) {
          pm.mediator.trigger('showSignInModal', {
            title: 'Improve your skills in Postman',
            subtitle: 'Learn about different features inside Postman and improve your skills through an interactive tutorial. Please create an account to continue.',
            renderIcon: this.renderIcon,
            onAuthentication: this.openBootcampTab,
            origin: 'learning_center' });

          return;
        }

        this.openBootcampTab();
        this.handleReset();
      }

      renderIcon() {
        return React.createElement('div', { className: 'learning-center-empty-state-icon' });
      }

      handleReset(e) {
        e && e.stopPropagation();
        this.setState(defaultState);
      }

      handleContinue(pausedLessonId) {
        this.setState({
          dismissable: true,
          currentState: HIGHLIGHT_STATE,
          label: 'Continue learning',
          pausedLessonId });

      }

      handleHighlightLessonButton() {
        this.setState({
          currentState: HIGHLIGHT_STATE,
          label: 'Bootcamp' });

      }

      render() {
        let { Item, Text } = StatusBarComponents;

        return (
          React.createElement(Item, {
              className: 'plugin__learningCenter',
              tooltip: 'Learning Center' },

            React.createElement(Text, {
              render: () => {
                return (
                  React.createElement(__WEBPACK_IMPORTED_MODULE_5__js_components_base_XPaths_XPath__["a" /* default */], { identifier: 'learningCenter' },
                    React.createElement('div', {
                        className: __WEBPACK_IMPORTED_MODULE_0_classnames___default()('learning-center-button', this.state.currentState),
                        onClick: this.handleClick },

                      React.createElement(__WEBPACK_IMPORTED_MODULE_6__js_components_base_Icons_BootcampIcon__["a" /* default */], null),
                      React.createElement('span', { className:
                          __WEBPACK_IMPORTED_MODULE_0_classnames___default()(
                          { 'dismissable': this.state.dismissable },
                          'learning-center-label') },


                        this.state.label),


                      this.state.dismissable &&
                      React.createElement(__WEBPACK_IMPORTED_MODULE_7__js_components_base_Icons_CloseIcon__["a" /* default */], { size: 'xs', onClick: this.handleReset }))));




              } })));



      }};

  } });
/* WEBPACK VAR INJECTION */}.call(__webpack_exports__, __webpack_require__(0)))

/***/ }),

/***/ 5678:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_classnames__ = __webpack_require__(7);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_classnames___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_classnames__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_mobx_react__ = __webpack_require__(4);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__components_base_Icons_RunIcon__ = __webpack_require__(4706);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__components_base_XPaths_XPath__ = __webpack_require__(20);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__base_Tooltips__ = __webpack_require__(51);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__runtime_components_agent_AgentSelectionContainer__ = __webpack_require__(5679);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__runtime_constants_AgentConstants__ = __webpack_require__(97);











/* harmony default export */ __webpack_exports__["a"] = ({
  name: 'AgentSelection',
  position: 'right',

  getComponent: function ({
    React,
    PluginInterface,
    StatusBarComponents })
  {var _class;
    return Object(__WEBPACK_IMPORTED_MODULE_2_mobx_react__["b" /* observer */])(_class = class AgentSelection extends React.Component {
      constructor(props) {
        super(props);

        this.state = {
          isOpen: false };


        this.handleOpen = this.handleOpen.bind(this);
        this.handleClick = this.handleClick.bind(this);
      }

      handleOpen() {
        this.setState({ isOpen: true });
      }

      handleClick() {
        this.setState(({ isOpen }) => ({ isOpen: !isOpen }));
      }

      componentWillMount() {
        pm.mediator.on('showAgentSelectionPopover', this.handleOpen);
      }

      componentWillUnmount() {
        pm.mediator.off('showAgentSelectionPopover', this.handleOpen);
      }

      getIcon() {
        const { state: agentState } = pm.runtime.agent.stat,
        className = __WEBPACK_IMPORTED_MODULE_1_classnames___default()('agent-selection-icon', { 'has-error': agentState === __WEBPACK_IMPORTED_MODULE_7__runtime_constants_AgentConstants__["f" /* STATES */].DISCONNECTED });

        return (
          React.createElement(__WEBPACK_IMPORTED_MODULE_3__components_base_Icons_RunIcon__["a" /* default */], { className: className }));

      }

      render() {
        if (!(window.SDK_PLATFORM === 'browser')) {
          return null;
        }

        let { Item, Icon } = StatusBarComponents;

        return (
          React.createElement(__WEBPACK_IMPORTED_MODULE_4__components_base_XPaths_XPath__["a" /* default */], { identifier: 'runtime-agent' },
            React.createElement('div', { ref: ref => {this.containerRef = ref;} },
              React.createElement(Item, {
                  className: 'plugin__agent-selection-shortcut' },

                React.createElement(Icon, {
                  onClick: this.handleClick,
                  className: 'plugin__agent-selection__icon',
                  icon: this.getIcon() })),


              React.createElement(__WEBPACK_IMPORTED_MODULE_5__base_Tooltips__["a" /* Tooltip */], {
                  className: 'agent-selection__details',
                  show: this.state.isOpen,
                  target: this.containerRef,
                  placement: 'top',
                  immediate: true },

                React.createElement(__WEBPACK_IMPORTED_MODULE_6__runtime_components_agent_AgentSelectionContainer__["a" /* default */], null)))));




      }}) || _class;

  } });

/***/ }),

/***/ 5679:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return AgentSelectionContainer; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_classnames__ = __webpack_require__(7);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_classnames___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_classnames__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_mobx_react__ = __webpack_require__(4);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__base_atom__ = __webpack_require__(711);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__base_molecule__ = __webpack_require__(1318);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__js_components_base_Text__ = __webpack_require__(253);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__js_components_base_Icons_ErrorIcon__ = __webpack_require__(268);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__constants_AgentConstants__ = __webpack_require__(97);
var _class;








let


AgentSelectionContainer = Object(__WEBPACK_IMPORTED_MODULE_2_mobx_react__["b" /* observer */])(_class = class AgentSelectionContainer extends __WEBPACK_IMPORTED_MODULE_0_react__["Component"] {
  constructor(props) {
    super(props);

    this.handleAgentSelect = this.handleAgentSelect.bind(this);
    this.renderSelectionDropdown = this.renderSelectionDropdown.bind(this);
    this.handleAgentOnboardingOpen = this.handleAgentOnboardingOpen.bind(this);
  }

  getMessage(isXHR, hasError) {
    if (!isXHR && hasError) {
      return (
        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('div', null,
          __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span', null, 'Ensure that your agent is '),
          __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span', { className: 'details__install', onClick: this.handleAgentOnboardingOpen }, 'installed'),
          __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span', null, ' and running in the background.')));


    }

    return `Postman will send your requests through the ${
    isXHR ? 'browser' : 'desktop'
    }. Certain limitations might apply.`;
  }

  handleAgentOnboardingOpen() {
    this.props.onClose && this.props.onClose();
    __WEBPACK_IMPORTED_MODULE_4__base_molecule__["g" /* openAgentOnboardingModal */] && Object(__WEBPACK_IMPORTED_MODULE_4__base_molecule__["g" /* openAgentOnboardingModal */])();
  }

  handleAgentSelect(option) {
    pm.settings.setSetting(__WEBPACK_IMPORTED_MODULE_7__constants_AgentConstants__["c" /* SETTING_KEY */], option);
  }

  renderSelectionDropdown(isXHR, hasError) {
    const options = Object.values(__WEBPACK_IMPORTED_MODULE_7__constants_AgentConstants__["e" /* SETTING_VALUES */]),
    selection = isXHR ? __WEBPACK_IMPORTED_MODULE_7__constants_AgentConstants__["e" /* SETTING_VALUES */].BROWSER.key : __WEBPACK_IMPORTED_MODULE_7__constants_AgentConstants__["e" /* SETTING_VALUES */].DESKTOP.key;

    return (
      __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__base_molecule__["a" /* Dropdown */], {
          className: 'agent-selection-details__dropdown',
          onSelect: this.handleAgentSelect },

        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__base_molecule__["b" /* DropdownButton */], {
            className: __WEBPACK_IMPORTED_MODULE_1_classnames___default()(
            'selection-details__dropdown-button',
            { 'has-error': hasError }) },


          __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_3__base_atom__["a" /* Button */], { size: 'small', fluid: true },
            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span', { className: 'selection-details__label' },
              selection),

            hasError && __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__js_components_base_Icons_ErrorIcon__["a" /* default */], null))),



        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__base_molecule__["c" /* DropdownMenu */], { fluid: true },
          options.map(option =>
          __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_4__base_molecule__["e" /* MenuItem */], { key: option.key, refKey: option.key },
            __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('span', { className: 'selection-details__label' }, option.label))))));





  }

  render() {
    const { type: agentType } = pm.runtime.agent.stat,
    isXHR = agentType === __WEBPACK_IMPORTED_MODULE_7__constants_AgentConstants__["g" /* TYPES */].XHR,
    hasError = !pm.runtime.agent.isReady;

    return (
      __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('div', { className: 'agent-selection__details' },
        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('div', { className: 'details__header' },
          __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_5__js_components_base_Text__["a" /* default */], { type: 'label-primary-medium', value: 'Request Client / Agent' })),


        this.renderSelectionDropdown(isXHR, hasError),

        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('div', { className: __WEBPACK_IMPORTED_MODULE_1_classnames___default()('details__help', { 'is-error': !isXHR && hasError }) },
          this.getMessage(isXHR, hasError))));



  }}) || _class;

/***/ }),

/***/ 5680:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return Item; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_react___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_react__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_classnames__ = __webpack_require__(7);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_classnames___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_classnames__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__Text__ = __webpack_require__(4707);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__Icon__ = __webpack_require__(4708);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__Pane__ = __webpack_require__(4709);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__Drawer__ = __webpack_require__(4710);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__base_Tooltips__ = __webpack_require__(51);







let

Item = class Item extends __WEBPACK_IMPORTED_MODULE_0_react__["Component"] {
  constructor(props) {
    super(props);

    this.state = { showTooltip: false };

    this.handleToggleTooltip = this.handleToggleTooltip.bind(this);
  }

  handleToggleTooltip(value = !this.state.showTooltip) {
    if (this.props.isOpen && value) {
      // Do not show the tooltip if the status bar / pane is open
      this.setState({ showTooltip: false });
      return;
    }

    this.setState({ showTooltip: value });
  }

  getClasses() {
    return __WEBPACK_IMPORTED_MODULE_1_classnames___default()({
      'sb__item': true,
      'is-active': this.props.isOpen },
    this.props.className);
  }

  render() {
    return (
      __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement('div', {
          ref: 'item',
          className: this.getClasses() },


        __WEBPACK_IMPORTED_MODULE_0_react___default.a.Children.map(this.props.children, child => {
          if (child.type === __WEBPACK_IMPORTED_MODULE_3__Icon__["a" /* default */]) {
            return __WEBPACK_IMPORTED_MODULE_0_react___default.a.cloneElement(child, {
              onMouseEnter: this.handleToggleTooltip.bind(this, true),
              onMouseLeave: this.handleToggleTooltip.bind(this, false) });

          } else
          if (child.type === __WEBPACK_IMPORTED_MODULE_2__Text__["a" /* default */]) {
            return __WEBPACK_IMPORTED_MODULE_0_react___default.a.cloneElement(child);
          } else
          if (child.type === __WEBPACK_IMPORTED_MODULE_4__Pane__["a" /* default */]) {
            return __WEBPACK_IMPORTED_MODULE_0_react___default.a.cloneElement(child, {
              isOpen: this.props.isOpen,
              onClose: this.props.toggleActive });

          } else
          if (child.type === __WEBPACK_IMPORTED_MODULE_5__Drawer__["a" /* default */]) {
            return __WEBPACK_IMPORTED_MODULE_0_react___default.a.cloneElement(child, {
              isOpen: this.props.isOpen,
              onClose: this.props.toggleActive });

          } else
          {
            throw new Error('Invalid child type, must be Icon, Text, Drawer or Pane');
          }
        }),


        this.props.tooltip &&
        __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__base_Tooltips__["a" /* Tooltip */], {
            show: this.state.showTooltip,
            target: this.refs.item,
            placement: 'top' },

          __WEBPACK_IMPORTED_MODULE_0_react___default.a.createElement(__WEBPACK_IMPORTED_MODULE_6__base_Tooltips__["b" /* TooltipBody */], null,
            this.props.tooltip))));





  }};

/***/ })

});